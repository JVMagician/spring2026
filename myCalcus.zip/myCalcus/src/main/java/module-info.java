module com.example.mycalc {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens com.example.mycalc to javafx.fxml;
    exports com.example.mycalc;
}