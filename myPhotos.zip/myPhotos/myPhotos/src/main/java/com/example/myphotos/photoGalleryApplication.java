package com.example.myphotos;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class photoGalleryApplication extends Application {

    private int imageWidth = 840;
    private int imageHeight = 600;

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(photoGalleryApplication.class.getResource("photoGallery-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), imageWidth, imageHeight);
        stage.setTitle("Photos");

        // Disable resizing
        stage.setResizable(false);

        // Disable maximizing
        stage.setMaximized(false);

        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}