package com.example.myphotos;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class photoGalleryController {



    @FXML
    public void initialize() {

    }

    @FXML
    protected void onPrevButtonClick() {

    }

    @FXML
    protected void onNextButtonClick() {

    }
}