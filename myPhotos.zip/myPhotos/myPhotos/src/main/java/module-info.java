module com.example.myphotos {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens com.example.myphotos to javafx.fxml;
    exports com.example.myphotos;
}